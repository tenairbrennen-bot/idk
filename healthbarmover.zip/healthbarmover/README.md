# Health Bar Mover (Fabric, Minecraft 1.21.11)

Press **H** in-game, drag with the left mouse button, press **Done**.
Position is saved to `config/healthbarmover.properties`. **Reset** puts it back.

## Get the .jar (no installs)
1. Create a free account at github.com and make a new repository.
2. Upload everything in this folder (including the hidden `.github` folder) to it.
3. Open the repo's **Actions** tab, wait for the "build" run to finish (about 3-5 minutes).
4. Open the finished run, download **healthbarmover-jar**, unzip it, and put the .jar in
   your `.minecraft/mods` folder along with Fabric Loader 0.18+ and Fabric API for 1.21.11.

## Or build locally
Needs JDK 21 and Gradle 9.2+: `gradle build`, then use `build/libs/healthbarmover-1.0.0.jar`.
