package dev.healthbarmover;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class MoveScreen extends Screen {
    // Vanilla health bar: 81x9 at (width/2 - 91, height - 39)
    private static final int BAR_W = 81;
    private static final int BAR_H = 9;

    public MoveScreen() {
        super(Component.translatable("screen.healthbarmover.title"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        this.addRenderableWidget(Button.builder(
                Component.translatable("screen.healthbarmover.reset"),
                b -> { Config.offsetX = 0f; Config.offsetY = 0f; })
                .bounds(cx - 105, 40, 100, 20).build());
        this.addRenderableWidget(Button.builder(
                Component.translatable("screen.healthbarmover.done"),
                b -> this.onClose())
                .bounds(cx + 5, 40, 100, 20).build());
    }

    // Intentionally no @Override: keeps the screen free of the dark/blur background
    // so the real health bar stays visible while you drag it.
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);

        int x = this.width / 2 - 91 + (int) Config.offsetX;
        int y = this.height - 39 + (int) Config.offsetY;
        int c = 0xFFFFFF55;
        g.fill(x - 2, y - 2, x + BAR_W + 2, y - 1, c);
        g.fill(x - 2, y + BAR_H + 1, x + BAR_W + 2, y + BAR_H + 2, c);
        g.fill(x - 2, y - 2, x - 1, y + BAR_H + 2, c);
        g.fill(x + BAR_W + 1, y - 2, x + BAR_W + 2, y + BAR_H + 2, c);

        g.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFFFF);
        g.drawCenteredString(this.font,
                Component.translatable("screen.healthbarmover.hint"), this.width / 2, 27, 0xFFAAAAAA);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (super.mouseDragged(event, dragX, dragY)) return true;
        if (event.button() == 0) {
            float minX = -(this.width / 2f - 91f);
            float maxX = this.width - BAR_W - (this.width / 2f - 91f);
            float minY = -(this.height - 39f);
            float maxY = this.height - BAR_H - (this.height - 39f);
            Config.offsetX = Math.max(minX, Math.min(maxX, Config.offsetX + (float) dragX));
            Config.offsetY = Math.max(minY, Math.min(maxY, Config.offsetY + (float) dragY));
            return true;
        }
        return false;
    }

    // No @Override on purpose; called when the screen closes.
    public void removed() {
        Config.save();
    }
}
