package dev.healthbarmover;

import net.fabricmc.loader.api.FabricLoader;

import java.io.OutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    public static float offsetX = 0f;
    public static float offsetY = 0f;

    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir().resolve("healthbarmover.properties");

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (InputStream in = Files.newInputStream(FILE)) {
            Properties p = new Properties();
            p.load(in);
            offsetX = Float.parseFloat(p.getProperty("x", "0"));
            offsetY = Float.parseFloat(p.getProperty("y", "0"));
        } catch (Exception e) {
            offsetX = 0f;
            offsetY = 0f;
        }
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(FILE)) {
            Properties p = new Properties();
            p.setProperty("x", Float.toString(offsetX));
            p.setProperty("y", Float.toString(offsetY));
            p.store(out, "Health Bar Mover offsets (GUI pixels from vanilla position)");
        } catch (Exception ignored) {
        }
    }
}
